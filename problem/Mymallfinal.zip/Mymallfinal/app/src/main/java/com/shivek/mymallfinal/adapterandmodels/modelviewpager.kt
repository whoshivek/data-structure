package com.shivek.mymallfinal.adapterandmodels

data class modelviewpager
    (

    val banner : Int? = null

)

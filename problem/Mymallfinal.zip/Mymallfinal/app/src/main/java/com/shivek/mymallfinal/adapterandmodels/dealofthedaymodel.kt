package com.shivek.mymallfinal.adapterandmodels

data class dealofthedaymodel(


    val text1 : String? = null,
       val text2 : String? = null,
    val text3 : String? = null,
    val image : Int? = null




)
package com.shivek.mymallfinal.adapterandmodels

data class myordermodel(

    val name : String,
     val image : Int
)
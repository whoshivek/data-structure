package com.shivek.mymallfinal.adapterandmodels

data class myrewardsmodel(

    val rewardstitle: String?= null,
    val rewardsvalid: String?= null,
    val rewardsdetails: String?= null
)
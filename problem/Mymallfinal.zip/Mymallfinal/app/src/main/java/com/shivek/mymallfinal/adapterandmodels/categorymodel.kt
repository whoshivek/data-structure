package com.shivek.mymallfinal.adapterandmodels

data class categorymodel(
    val link : String? = null,
val text : String? = null


)
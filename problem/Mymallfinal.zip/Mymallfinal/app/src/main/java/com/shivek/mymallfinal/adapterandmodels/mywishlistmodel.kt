package com.shivek.mymallfinal.adapterandmodels

data class mywishlistmodel(

    val name : String? = null,
    val image : Int? = null,
    val price: String? = null
)
package com.shivek.mymallfinal.adapterandmodels

data class mycartmodel (


    val type : Int?= null,
    ////////////cart item/////////////////////////
val image : Int? =null,
    val name:String?= null,
    val price : String?= null,
////////////////////////////////////////////

///////////////////////cart_totalamount////////////////////
val totalamount : String?= null,
    val delivert : String?= null


/////////////////////////////////////////
)